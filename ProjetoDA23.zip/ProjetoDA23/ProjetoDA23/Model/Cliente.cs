﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Model
{
    internal class Cliente: Pessoa
    {
        public int NumFiscal { get; set; }

        public override string ToString()
        {
            string result = "Nome:" + this.Nome + "|| Morada:" + Morada + "|| Nif:" + NumFiscal;
            return result;
        }
    }
}

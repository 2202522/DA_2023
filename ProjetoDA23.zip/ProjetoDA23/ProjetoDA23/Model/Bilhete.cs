﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Model
{
    internal class Bilhete
    {
        public int Id { get; set; }
        public string Lugar { get; set; }
        public string Estado { get; set; }
        public Funcionario funcionario { get; set; }
        public Cliente cliente { get; set; }

        public override string ToString()
        {
            string result = "Bilhete Lugar:" + this.Lugar;
            return result;
        }
    }
}

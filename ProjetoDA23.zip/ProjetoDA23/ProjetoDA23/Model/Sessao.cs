﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Model
{
    internal class Sessao
    {
        public int Id { get; set; }
        public DateTime DataHora { get; set; }
        public double Preco { get; set; }
        public virtual Filme filme { get; set; }
        public Sala sala { get; set; }
        public List<Bilhete> bilhete { get; set; }

        public override string ToString()
        {
            string result = "DataHora:" + this.DataHora + " | Preço:" + Preco+ " | Filme: "+ this.filme.Nome;
            return result;
        }
    }
}

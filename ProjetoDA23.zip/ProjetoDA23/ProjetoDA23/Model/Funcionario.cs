﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Model
{
    internal class Funcionario: Pessoa
    {
        public double Salario { get; set; }
        public string Funcao { get; set; }

        public override string ToString()
        {
            string result = "Nome:" + this.Nome + "|| Morada:" + Morada + "|| Salario:" + Salario;
            return result;
        }
    }
}

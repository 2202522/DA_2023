﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Model
{
    internal class Filme
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int Duracao { get; set; }
        public string Estado { get; set; }
        public Categoria categoria { get; set; }

        public override string ToString()
        {
            string result = "Nome:" + this.Nome + " || Duracao:" + Duracao + " || Estado:" + Estado + " || Categoria" ;
            return result;
        }
    }
}

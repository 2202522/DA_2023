﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Model
{
    internal class Sala
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int Colunas { get; set; }
        public int Filas { get; set; }
        public List<Sessao> Sessao { get; set; }

        public override string ToString()
        {
            string result = "Nome:" + this.Nome + " | Colunas:" + Colunas + " | Filas:" + Filas;
            return result;
        }
    }
}

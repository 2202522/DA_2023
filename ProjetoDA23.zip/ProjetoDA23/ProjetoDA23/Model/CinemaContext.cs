﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace ProjetoDA23.Model
{
    internal class CinemaContext: DbContext
    {
        public DbSet<Bilhete> Bilhete { get; set; }
        public DbSet<Categoria> Categoria { get; set; }
        public DbSet<Cinema> Cinema { get; set; }
        public DbSet<Cliente> Cliente { get; set; }
        public DbSet<Funcionario> Funcionario { get; set; }
        public DbSet<Pessoa> Pessoa { get; set; }
        public DbSet<Sala> Sala { get; set; }
        public DbSet<Sessao> Sessao { get; set; }
        public DbSet<Filme> Filme { get;  set; }
    }
}

﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class CategoriaController
    {
        public static List<Categoria> GetCategorias()
        {
            using (var db = new CinemaContext())
            {
                return db.Categoria.ToList();
            }
        }
        public static void ADDCategoria(String Nome, String Estado)
        {
            using (var db = new CinemaContext())
            {
                Categoria categoria = new Categoria();
                categoria.Nome = Nome;
                categoria.Estado = Estado;
                db.Categoria.Add(categoria);
                db.SaveChanges();
            }
        }
        public static void UpdateCategoria(Int32 ID, String NomeUpdate, String EstadoUpdate)
        {

            using (var db = new CinemaContext())
            {
                Categoria Categoria = db.Categoria.Where(c => c.Id == ID).FirstOrDefault();
                Categoria.Nome= NomeUpdate;
                Categoria.Estado= EstadoUpdate;
                db.SaveChanges();
            }
        }
    }
}

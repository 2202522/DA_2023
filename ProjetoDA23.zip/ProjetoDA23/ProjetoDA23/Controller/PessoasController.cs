﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class PessoasController
    {
        public static List<Pessoa> GetPessoas()
        {
            using (var db = new CinemaContext())
            {
                return db.Pessoa.ToList();
            }
        }
    }
}

﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class ExportarController
    {
        public static void ExportarBilhete(Int32 idSessao, string NomeCliente, string NomeFuncionario, string colunas, string filas)
        {
            using (var db = new CinemaContext())
            {
                Funcionario Funcionario = db.Funcionario.Where(c => c.Nome == NomeFuncionario).FirstOrDefault();
                Cliente Cliente = db.Cliente.Where(c => c.Nome == NomeCliente).FirstOrDefault();
                Sessao Sessao = db.Sessao.Where(c => c.Id == idSessao).FirstOrDefault();
                db.Sessao.Include("Filme").ToList();
                db.Sessao.Include("Sala").ToList();
                db.Sessao.Include("Bilhete").ToList();
                string nomeTxt = Cliente.Nome+".txt";
                FileStream fs = new FileStream(nomeTxt, FileMode.Create, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);

                sw.WriteLine(Cliente.Nome + " NIF(" + Cliente.NumFiscal + ")");
                sw.WriteLine("________________________________________________________");
                sw.WriteLine("Hora: " + Sessao.DataHora );
                sw.WriteLine("Preço: " + Sessao.Preco + "€");
                sw.WriteLine("Filme: " + Sessao.filme.Nome);
                sw.WriteLine("Sala: " + Sessao.sala.Nome+ ", " +"Lugar [" + colunas + "-" + filas + "]");
                sw.WriteLine("Funcionario: "+Funcionario.Nome);
                sw.WriteLine("Bilhete emitido a: "+DateTime.Now);
                sw.Close();
                fs.Close();
            }
        }
    }
}

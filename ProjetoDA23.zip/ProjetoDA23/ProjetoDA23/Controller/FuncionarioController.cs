﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class FuncionarioController
    {
        public static List<Funcionario> GetFuncionario()
        {
            using (var db = new CinemaContext())
            {
                return db.Funcionario.ToList();
            }
        }
        public static void ADDFuncionario(String Nome, String Morada, Int32 Salario, String Funcao)
        {
            using (var db = new CinemaContext())
            {
                Funcionario funcionario = new Funcionario();
                funcionario.Nome = Nome;
                funcionario.Morada = Morada;
                funcionario.Salario = Salario;
                funcionario.Funcao = Funcao;
                db.Funcionario.Add(funcionario);
                db.SaveChanges();
            }
        }
        public static void UpdateFuncionario(Int32 ID, String NomeUpdate, String MoradaUpdate, Int32 SalarioUpdate, String FuncaoUpdate)
        {
            using (var db = new CinemaContext())
            {
                Funcionario Funcionario = db.Funcionario.Where(c => c.Id == ID).FirstOrDefault();
                Funcionario.Nome=NomeUpdate;
                Funcionario.Morada=MoradaUpdate;
                Funcionario.Salario = SalarioUpdate;
                Funcionario.Funcao=FuncaoUpdate;
                db.SaveChanges();
            }
        }

        public static void DeleteFuncionario(Int32 ID)
        {
            using (var db = new CinemaContext())
            {
                Funcionario Funcionario = db.Funcionario.Where(c => c.Id == ID).FirstOrDefault();
                db.Funcionario.Remove(Funcionario);
                db.SaveChanges();
            }
        }
    }
}

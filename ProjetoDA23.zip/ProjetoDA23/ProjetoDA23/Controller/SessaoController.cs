﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class SessaoController
    {
        public static List<Sessao> GetSessao()
        {
            using (var db = new CinemaContext())
            {
                db.Sessao.Include("Filme").ToList();
                db.Sessao.Include("Sala").ToList();
                db.Sessao.Include("Bilhete").ToList();
                return db.Sessao.ToList();
            }
        }

        public static List<Filme> GetFilme()
        {
            using (var db = new CinemaContext())
            {
                return db.Filme.ToList();
            }
        }

        public static void ADDSessao(DateTime DataHora, double Preco, String FilmeNome, String SalaNome)
        {
            using (var db = new CinemaContext())
            {
                Sessao sessao = new Sessao();
                sessao.DataHora= DataHora;
                sessao.Preco= Preco;
                Filme Filme = db.Filme.Where(c => c.Nome == FilmeNome).FirstOrDefault();
                sessao.filme = Filme;
                Sala Sala = db.Sala.Where(c => c.Nome == SalaNome).FirstOrDefault();
                sessao.sala = Sala;
                db.Sessao.Add(sessao);
                db.SaveChanges();
            }
        }

        public static void UpdateSessao(Int32 ID,DateTime DataHoraUpdate, double PrecoUpdate, String FilmeNomeUpdate, String SalaNomeUpdate)
        {
            using (var db = new CinemaContext())
            {
                Sessao Sessao = db.Sessao.Where(c => c.Id == ID).FirstOrDefault();
                Sessao.DataHora = DataHoraUpdate;
                Sessao.Preco = PrecoUpdate;
                Filme Filme = db.Filme.Where(c => c.Nome == FilmeNomeUpdate).FirstOrDefault();
                Sessao.filme = Filme;
                Sala Sala = db.Sala.Where(c => c.Nome == SalaNomeUpdate).FirstOrDefault();
                Sessao.sala = Sala;
                //BilheteController.CreateBilhetesSessao(Sala.Id);
                db.SaveChanges();
            }
        }

        public static void DeleteSessao(Int32 ID)
        {
            using (var db = new CinemaContext())
            {
                Sessao Sessao = db.Sessao.Where(c => c.Id == ID).FirstOrDefault();
                db.Sessao.Remove(Sessao);
                db.SaveChanges();
            }
        }

        public static bool IsLugarOcupado(List<Bilhete> bilhetes ,string lugar)
        {
            foreach (var bilhete in bilhetes)
            {
                if (bilhete.Lugar == lugar)
                    return true;
            }

            return false;
        }
        public static List<Bilhete> GetBilhetesDaSessao(int sessaoId)
        {
            using (var db = new CinemaContext())
            {
                Sessao sessao = db.Sessao.Where(c => c.Id == sessaoId).Include("Bilhete").FirstOrDefault();

                if (sessao != null)
                {
                    List<Bilhete> bilhetes = sessao.bilhete.ToList();
                    return bilhetes;
                }

                return new List<Bilhete>();
            }
        }
        public static bool PodeCriarSessao(string NomeSala, DateTime dataHora)
        {
            using (var db = new CinemaContext())
            {
                Sala sala = db.Sala.Where(c => c.Nome == NomeSala).Include("Sessao").FirstOrDefault();
            
                if (sala.Sessao != null)
                {
                    
                    foreach (var sessao in sala.Sessao)
                    {
                        
                        if (sessao.DataHora == dataHora)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
        }
    }
}

﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.EntitySql;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class MainController
    {
        public static void FuncionarioLogin(string funcionario)
        {

        }
    }
}

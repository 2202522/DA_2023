﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace ProjetoDA23.Controller
{
    internal class FilmeController
    {
        public static List<Filme> GetFilmes()
        {
            using (var db = new CinemaContext())
            {
                db.Filme.Include("Categoria").ToList();
                return db.Filme.ToList();
            }
        }

        public static void ADDFilme(String Nome, String Duracao , String Estado, String CategoriaNome)
        {
            using (var db = new CinemaContext())
            {
                Filme filme = new Filme();
                filme.Nome = Nome;
                filme.Duracao = Convert.ToInt32(Duracao);
                filme.Estado = "Inativo";
                Categoria Categoria = db.Categoria.Where(c => c.Nome== CategoriaNome).FirstOrDefault();
                filme.categoria = Categoria;
                db.Filme.Add(filme);
                db.SaveChanges();
            }
        }

        public static void UpdateFilme(Int32 ID, String NomeUpdate, String DuracaoUpdate, String EstadoUpdate, String CategoriaUpdate)
        {

            using (var db = new CinemaContext())
            {
                Filme Filme = db.Filme.Where(c => c.Id == ID).FirstOrDefault();
                Filme.Nome=NomeUpdate;
                Filme.Duracao= Convert.ToInt32(DuracaoUpdate);
                Filme.Estado=EstadoUpdate;
                Categoria Categoria = db.Categoria.Where(c => c.Nome == CategoriaUpdate).FirstOrDefault();
                Filme.categoria= Categoria;
                db.SaveChanges();
            }
        }
    }
}

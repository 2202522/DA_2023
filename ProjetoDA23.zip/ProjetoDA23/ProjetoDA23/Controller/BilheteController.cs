﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Mapping;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class BilheteController
    {
        public static List<Bilhete> GetBilhete()
        {
            using (var db = new CinemaContext())
            {
                db.Bilhete.Include("Cliente").ToList();
                db.Bilhete.Include("Funcionario").ToList();
                return db.Bilhete.ToList();
            }
        }
        public static void CreateBilhetes(Int32 colunas, Int32 filas, string NomeCliente, string NomeFuncionario, Int32 IdSessao)
        {
            using (var db = new CinemaContext())
            {
                Bilhete bilhete = new Bilhete();
                string coluna = colunas.ToString();
                string fila = filas.ToString();
                bilhete.Lugar = ("[" + coluna + "-" + fila + "]");
                bilhete.Estado = "Ocupado";
                Funcionario Funcionario = db.Funcionario.Where(c => c.Nome == NomeFuncionario).FirstOrDefault();
                Cliente Cliente = db.Cliente.Where(c => c.Nome == NomeCliente).FirstOrDefault();
                bilhete.cliente = Cliente;
                bilhete.funcionario = Funcionario;
                Sessao Sessao = db.Sessao.Where(c => c.Id == IdSessao).FirstOrDefault();
                if (Sessao != null)
                {
                    if (Sessao.bilhete == null)
                    {
                        Sessao.bilhete = new List<Bilhete>();
                    }
                    Sessao.bilhete.Add(bilhete);
                }
                db.Bilhete.Add(bilhete);
                db.SaveChanges();
            }
        }

        public static Sessao PreencherLabels(string sessao)
        {
            using (var db = new CinemaContext())
            {
                Sessao Sessao = db.Sessao.Where(c => c.Id == Convert.ToInt32(sessao)).FirstOrDefault();
                return Sessao;
            }
        }

        public static string Sala(Int32 IdSala)
        {
            using (var db = new CinemaContext())
            {
                Sala sala = db.Sala.Where(c => c.Id == IdSala).FirstOrDefault();
                Int32 colunas = sala.Colunas;
                Int32 filas = sala.Filas;
                Int32 i;
                Int32 x;
                string lugar;

                for (i = 0; i <= filas; i++)
                {
                    for (x = 0; x <= colunas; i++)
                    {
                         lugar = ("[" + i + "-" + x + "]");
                    }
                }
                return sala.ToString();
            }
        }
    }
}

﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class CinemaController
    {
        public static List<Cinema> GetCinemas()
        {
            using (var db = new CinemaContext())
            {
                return db.Cinema.ToList();
            }
        }
        public static void ADDCinema(String Nome, String Morada, String Email)
        {
            using (var db = new CinemaContext())
            {
                    Cinema cinema = new Cinema();
                    cinema.Nome = Nome;
                    cinema.Morada = Morada;
                    cinema.Email = Email;
                    db.Cinema.Add(cinema);
                    db.SaveChanges();
            }
        }
        public static void UpdateCinema(Int32 ID,String NomeUpdate, String MoradaUpdate, String EmailUpdate)
        {
            using (var db = new CinemaContext())
            {
                Cinema Cinema = db.Cinema.Where(c => c.Id == ID).FirstOrDefault();
                Cinema.Nome = NomeUpdate;
                Cinema.Morada = MoradaUpdate;
                Cinema.Email = EmailUpdate;
                db.SaveChanges();
            }
        }
    }
}
﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class ClienteController
    {
        public static List<Cliente> GetClientes()
        {
            using (var db = new CinemaContext())
            {
                return db.Cliente.ToList();
            }
        }
        public static void ADDCliente(String Nome, String Morada, Int32 Nif)
        {
            using (var db = new CinemaContext())
            {
                Cliente cliente = new Cliente();
                cliente.Nome = Nome;
                cliente.Morada = Morada;
                cliente.NumFiscal = Nif;
                db.Cliente.Add(cliente);
                db.SaveChanges();
            }
        }
        public static void UpdateCliente(Int32 ID, String NomeUpdate, String MoradaUpdate, Int32 NumFiscalUpdate)
        {
            using (var db = new CinemaContext())
            {
                Cliente Cliente = db.Cliente.Where(c => c.Id == ID).FirstOrDefault();
                Cliente.Nome = NomeUpdate;
                Cliente.Morada = MoradaUpdate;
                Cliente.NumFiscal = NumFiscalUpdate;
                db.SaveChanges();
            }
        }

        public static void DeleteCliente(Int32 ID)
        {
            using (var db = new CinemaContext())
            {
                Cliente Cliente = db.Cliente.Where(c => c.Id == ID).FirstOrDefault();
                db.Cliente.Remove(Cliente);
                db.SaveChanges();
            }
        }

        public static List<Bilhete> GetBilhetesPessoa(int clienteId)
        {
            using (var db = new CinemaContext())
            {
                List<Bilhete> bilhete = db.Bilhete.Where(c => c.cliente.Id == clienteId).Include("Cliente").ToList();
                return bilhete;
           }
        }

        public static int GetTotalPreco(Int32 idCliente)
        {
            using (var db = new CinemaContext())
            {
                List<Bilhete> bilhetesCliente = ObterBilhetesPorIdCliente(idCliente);
                //List<Sessao> sessao= db.Sessao.Where(c => c.bilhete.).Include("Cliente").ToList();
                return 5;
            }
        }
        public static List<Bilhete> ObterBilhetesPorIdCliente(int idCliente)
        {
            using(var db = new CinemaContext()) 
            { 
                List<Bilhete> bilhetesCliente = db.Bilhete.Where(b => b.cliente.Id == idCliente).Include("Cliente").ToList();
                return bilhetesCliente;
            }
        }
    }
}

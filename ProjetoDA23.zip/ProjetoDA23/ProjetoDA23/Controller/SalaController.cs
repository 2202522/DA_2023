﻿using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoDA23.Controller
{
    internal class SalaController
    {
        public static List<Sala> GetSalas()
        {
            using (var db = new CinemaContext())
            {
                return db.Sala.ToList();
            }
        }

        public static void ADDSala(String Nome, Int32 Colunas, Int32 Filas)
        {
            using (var db = new CinemaContext())
            {
                Sala sala = new Sala();
                sala.Nome = Nome;
                sala.Colunas = Colunas;
                sala.Filas = Filas;
                db.Sala.Add(sala);
                db.SaveChanges();
            }
        }
        public static void DeleteSala(Int32 ID)
        {
            using (var db = new CinemaContext())
            {
                Sala Sala = db.Sala.Where(c => c.Id == ID).FirstOrDefault();
                db.Sala.Remove(Sala);
                db.SaveChanges();
            }
        }
    }
}

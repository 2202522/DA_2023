﻿namespace ProjetoDA23
{
    partial class MainForm
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxFuncionario = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonBilhetes = new System.Windows.Forms.Button();
            this.buttonCategorias = new System.Windows.Forms.Button();
            this.buttonSalas = new System.Windows.Forms.Button();
            this.buttonRH = new System.Windows.Forms.Button();
            this.buttonSessões = new System.Windows.Forms.Button();
            this.buttonFilmes = new System.Windows.Forms.Button();
            this.buttonCinema = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(342, 224);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 29);
            this.label1.TabIndex = 6;
            this.label1.Text = "Filmes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(106, 430);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 29);
            this.label2.TabIndex = 7;
            this.label2.Text = "Salas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(314, 430);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 29);
            this.label3.TabIndex = 8;
            this.label3.Text = "Categorias";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(100, 224);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 29);
            this.label4.TabIndex = 9;
            this.label4.Text = "Cinema";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(586, 224);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 29);
            this.label5.TabIndex = 10;
            this.label5.Text = "Sessões";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(564, 430);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 29);
            this.label6.TabIndex = 11;
            this.label6.Text = "Gestão  RH";
            // 
            // comboBoxFuncionario
            // 
            this.comboBoxFuncionario.FormattingEnabled = true;
            this.comboBoxFuncionario.Location = new System.Drawing.Point(455, 12);
            this.comboBoxFuncionario.Name = "comboBoxFuncionario";
            this.comboBoxFuncionario.Size = new System.Drawing.Size(211, 28);
            this.comboBoxFuncionario.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(688, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 34);
            this.button1.TabIndex = 13;
            this.button1.Text = "login";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(357, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "Funcionario:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(92, 627);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 29);
            this.label8.TabIndex = 16;
            this.label8.Text = "Bilhetes";
            // 
            // buttonBilhetes
            // 
            this.buttonBilhetes.BackgroundImage = global::ProjetoDA23.Properties.Resources.ticket;
            this.buttonBilhetes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonBilhetes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBilhetes.Location = new System.Drawing.Point(72, 473);
            this.buttonBilhetes.Name = "buttonBilhetes";
            this.buttonBilhetes.Size = new System.Drawing.Size(150, 151);
            this.buttonBilhetes.TabIndex = 15;
            this.buttonBilhetes.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonBilhetes.UseVisualStyleBackColor = true;
            this.buttonBilhetes.Click += new System.EventHandler(this.buttonBilhetes_Click);
            // 
            // buttonCategorias
            // 
            this.buttonCategorias.BackgroundImage = global::ProjetoDA23.Properties.Resources.categoria;
            this.buttonCategorias.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCategorias.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCategorias.Location = new System.Drawing.Point(312, 277);
            this.buttonCategorias.Name = "buttonCategorias";
            this.buttonCategorias.Size = new System.Drawing.Size(150, 151);
            this.buttonCategorias.TabIndex = 5;
            this.buttonCategorias.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonCategorias.UseVisualStyleBackColor = true;
            this.buttonCategorias.Click += new System.EventHandler(this.buttonCategorias_Click);
            // 
            // buttonSalas
            // 
            this.buttonSalas.BackgroundImage = global::ProjetoDA23.Properties.Resources.salas;
            this.buttonSalas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSalas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSalas.Location = new System.Drawing.Point(72, 277);
            this.buttonSalas.Name = "buttonSalas";
            this.buttonSalas.Size = new System.Drawing.Size(150, 151);
            this.buttonSalas.TabIndex = 4;
            this.buttonSalas.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSalas.UseVisualStyleBackColor = true;
            this.buttonSalas.Click += new System.EventHandler(this.buttonSalas_Click);
            // 
            // buttonRH
            // 
            this.buttonRH.BackgroundImage = global::ProjetoDA23.Properties.Resources.gestao_RH;
            this.buttonRH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonRH.Location = new System.Drawing.Point(570, 277);
            this.buttonRH.Name = "buttonRH";
            this.buttonRH.Size = new System.Drawing.Size(150, 151);
            this.buttonRH.TabIndex = 3;
            this.buttonRH.UseVisualStyleBackColor = true;
            this.buttonRH.Click += new System.EventHandler(this.buttonRH_Click);
            // 
            // buttonSessões
            // 
            this.buttonSessões.BackgroundImage = global::ProjetoDA23.Properties.Resources.sessoes;
            this.buttonSessões.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSessões.Location = new System.Drawing.Point(570, 70);
            this.buttonSessões.Name = "buttonSessões";
            this.buttonSessões.Size = new System.Drawing.Size(150, 151);
            this.buttonSessões.TabIndex = 2;
            this.buttonSessões.UseVisualStyleBackColor = true;
            this.buttonSessões.Click += new System.EventHandler(this.buttonSessões_Click);
            // 
            // buttonFilmes
            // 
            this.buttonFilmes.BackgroundImage = global::ProjetoDA23.Properties.Resources.filmes;
            this.buttonFilmes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonFilmes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFilmes.Location = new System.Drawing.Point(312, 70);
            this.buttonFilmes.Name = "buttonFilmes";
            this.buttonFilmes.Size = new System.Drawing.Size(150, 151);
            this.buttonFilmes.TabIndex = 1;
            this.buttonFilmes.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonFilmes.UseVisualStyleBackColor = true;
            this.buttonFilmes.Click += new System.EventHandler(this.buttonFilmes_Click);
            // 
            // buttonCinema
            // 
            this.buttonCinema.BackgroundImage = global::ProjetoDA23.Properties.Resources.cinema;
            this.buttonCinema.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCinema.Location = new System.Drawing.Point(72, 70);
            this.buttonCinema.Name = "buttonCinema";
            this.buttonCinema.Size = new System.Drawing.Size(150, 151);
            this.buttonCinema.TabIndex = 0;
            this.buttonCinema.UseVisualStyleBackColor = true;
            this.buttonCinema.Click += new System.EventHandler(this.buttonCinema_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(789, 675);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.buttonBilhetes);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBoxFuncionario);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCategorias);
            this.Controls.Add(this.buttonSalas);
            this.Controls.Add(this.buttonRH);
            this.Controls.Add(this.buttonSessões);
            this.Controls.Add(this.buttonFilmes);
            this.Controls.Add(this.buttonCinema);
            this.Name = "MainForm";
            this.Text = "Main Page";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCinema;
        private System.Windows.Forms.Button buttonFilmes;
        private System.Windows.Forms.Button buttonSessões;
        private System.Windows.Forms.Button buttonCategorias;
        private System.Windows.Forms.Button buttonSalas;
        private System.Windows.Forms.Button buttonRH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxFuncionario;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonBilhetes;
    }
}


﻿using ProjetoDA23.Model;
using ProjetoDA23.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace ProjetoDA23.View
{
    public partial class BilheteForm : Form
    {
        CinemaContext cinemaContext;
        public BilheteForm()
        {
            InitializeComponent();
            cinemaContext = new CinemaContext();
        }

        private void BilheteForm_Load(object sender, EventArgs e)
        {
            var sessoes = SessaoController.GetSessao();
            var funcionarios = FuncionarioController.GetFuncionario();
            var clientes = ClienteController.GetClientes();

            comboBoxSessao.DataSource = sessoes;
            comboBoxSessao.ValueMember = "Id";
            comboBoxSessao.DisplayMember = "DataHora";

            comboBoxFuncionario.DataSource = funcionarios;
            comboBoxFuncionario.ValueMember = "Id";
            comboBoxFuncionario.DisplayMember = "Nome";

            comboBoxCliente.DataSource = clientes;
            comboBoxCliente.ValueMember = "Id";
            comboBoxCliente.DisplayMember = "Nome";

            comboBoxSessao.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxCliente.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxFuncionario.DropDownStyle = ComboBoxStyle.DropDownList;
            ClearTextBoxes();
        }

        private void labelSala_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBoxSessao_SelectedIndexChanged(object sender, EventArgs e)
        {
            Sessao sessao = comboBoxSessao.SelectedItem as Sessao;
            labelSala.Text = "Sala: "+sessao.sala.Nome;
            labelPreco.Text = "Preço: "+Convert.ToString(sessao.Preco)+" €";
            labelFilme.Text = "Filme: "+sessao.filme.Nome;
            label3.Text = "Lugares da Sala Colunas: " + sessao.sala.Colunas + " Filas: " + sessao.sala.Filas;
            LoadDataGrid();
            numericUpDownColunas.Value = 1;
            numericUpDownFila.Value = 1;
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        private void ClearTextBoxes()
        {
            comboBoxFuncionario.Text = null;
            comboBoxCliente.Text = null;
        }

        private void buttonBilhete_Click(object sender, EventArgs e)
        {
            Sessao sessao = comboBoxSessao.SelectedItem as Sessao;
            string fila = numericUpDownFila.Text;
            string coluna = numericUpDownColunas.Text;
            var lugar = $"[{coluna}-{fila}]";

            List<Bilhete> bilhetes = SessaoController.GetBilhetesDaSessao(sessao.Id);
            if (!SessaoController.IsLugarOcupado(bilhetes, lugar))
            {
                if (string.IsNullOrEmpty(numericUpDownColunas.Text) || string.IsNullOrEmpty(numericUpDownFila.Text)|| string.IsNullOrEmpty(comboBoxFuncionario.Text)|| string.IsNullOrEmpty(comboBoxCliente.Text))
                {
                    System.Windows.Forms.MessageBox.Show("Dados a vazio");
                }
                else
                {
                    BilheteController.CreateBilhetes(Convert.ToInt32(numericUpDownColunas.Text), Convert.ToInt32(numericUpDownFila.Text), comboBoxCliente.Text, comboBoxFuncionario.Text, Convert.ToInt32(sessao.Id));
                    ExportarController.ExportarBilhete(Convert.ToInt32(sessao.Id), comboBoxCliente.Text, comboBoxFuncionario.Text, numericUpDownColunas.Text, numericUpDownFila.Text);
                }
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Lugar Ocupado");
            }
            LoadDataGrid();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            dataGridView1.AutoGenerateColumns=false;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
        }

        public void LoadDataGrid()
        {
            Sessao sessaoSelecionada = (Sessao)comboBoxSessao.SelectedItem;
            List<Bilhete> bilhetes = SessaoController.GetBilhetesDaSessao(sessaoSelecionada.Id);


            int filas = sessaoSelecionada.sala.Filas;
            int colunas = sessaoSelecionada.sala.Colunas;

            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();

            for (int coluna = 1; coluna <= colunas; coluna++)
            {
                var column = new DataGridViewTextBoxColumn
                {
                    HeaderText = $"Coluna {coluna}",
                    DataPropertyName = $"Coluna{coluna}",
                    Width = 50
                };
                dataGridView1.Columns.Add(column);
            }

            for (int fila = 1; fila <= filas; fila++)
            {
                var row = new DataGridViewRow();
                for (int coluna = 1; coluna <= colunas; coluna++)
                {
                    var lugar = $"[{coluna}-{fila}]";

                    
                    var cell = new DataGridViewTextBoxCell
                    {
                        Value = lugar
                    };

                    if (SessaoController.IsLugarOcupado(bilhetes ,lugar)) { 
                        cell.Style.BackColor = Color.Red; 
                    }
                    else { cell.Style.BackColor = Color.Green;
                    }
                    row.Cells.Add(cell);
                }
                dataGridView1.Rows.Add(row);
            }
        }

        private void numericUpDownColunas_ValueChanged(object sender, EventArgs e)
        {
            Sessao sessaoSelecionada = (Sessao)comboBoxSessao.SelectedItem;
            int max = sessaoSelecionada.sala.Colunas;
            numericUpDownColunas.Maximum = max;
            numericUpDownColunas.Minimum = 1;
            numericUpDownColunas.ReadOnly = true;
        }

        private void numericUpDownFila_ValueChanged(object sender, EventArgs e)
        {
            Sessao sessaoSelecionada = (Sessao)comboBoxSessao.SelectedItem;
            int max = sessaoSelecionada.sala.Filas;
            numericUpDownFila.Maximum = max;
            numericUpDownFila.Minimum = 1;
            numericUpDownFila.ReadOnly = true;
        }
    }
}

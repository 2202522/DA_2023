﻿using ProjetoDA23.Controller;
using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace ProjetoDA23.View
{
    public partial class SalasForm : Form
    {
        CinemaContext cinemaContext;
        public SalasForm()
        {
            InitializeComponent();
            cinemaContext = new CinemaContext();
        }

        private void SalasForm_Load(object sender, EventArgs e)
        {
            var sala = SalaController.GetSalas();
            listBoxSalas.DataSource = sala;
            textBoxNome.Text = null;
            numericUpDownColunas.Text = null;
            numericUpDownFilas.Text = null;
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxNome.Text) || string.IsNullOrEmpty(numericUpDownColunas.Text) || string.IsNullOrEmpty(numericUpDownFilas.Text))
            {

                System.Windows.Forms.MessageBox.Show("Dados a vazio");

            }
            else
            {
                SalaController.ADDSala(textBoxNome.Text, Convert.ToInt32(numericUpDownColunas.Text), Convert.ToInt32(numericUpDownFilas.Text));
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {

            Sala sala = (Sala)listBoxSalas.SelectedItem;
            SalaController.DeleteSala(sala.Id);

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        private void listBoxSalas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxSalas.SelectedItem == null)
            {
                return;
            }
            else
            {
                Sala sala = (Sala)listBoxSalas.SelectedItem;

                textBoxNome.Text = sala.Nome;
                numericUpDownColunas.Text = sala.Colunas.ToString();
                numericUpDownFilas.Text = sala.Filas.ToString();
            }
        }

        private void numericUpDownColunas_ValueChanged(object sender, EventArgs e)
        {
            numericUpDownColunas.Maximum = 20;
            numericUpDownColunas.Minimum = 1;
            numericUpDownColunas.ReadOnly = true;

        }

        private void numericUpDownFilas_ValueChanged(object sender, EventArgs e)
        {
            numericUpDownFilas.Maximum = 25;
            numericUpDownFilas.Minimum = 1;
            numericUpDownFilas.ReadOnly = true;

        }
    }
}

﻿using ProjetoDA23.Controller;
using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoDA23.View
{
    public partial class ClientesForm : Form
    {
        CinemaContext cinemaContext;
        public ClientesForm()
        {
            InitializeComponent();
            cinemaContext = new CinemaContext();
        }

        private void listBoxClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxClientes.SelectedItem == null)
            {
                return;
            }
            else
            {
                Cliente cliente = (Cliente)listBoxClientes.SelectedItem;
                Int32 total;
                total = CalculaTotal(cliente.Id);
                labelValorTotal.Text = total +" €";
                LoadListBox();
            }
        }

        private void ClientesForm_Load(object sender, EventArgs e)
        {
            var cliente = ClienteController.GetClientes();
            listBoxClientes.DataSource = cliente;
        }

        public void LoadListBox()
        {
            Cliente clienteSelecionado = (Cliente)listBoxClientes.SelectedItem;
            List<Bilhete> bilhetes = ClienteController.GetBilhetesPessoa(clienteSelecionado.Id);
            listBoxBilhetes.DataSource = bilhetes;
        }

        public static Int32 CalculaTotal(Int32 idCliente)
        {
            int total= ClienteController.GetTotalPreco(idCliente);
            return total;
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            PessoasForm pessoasForm = new PessoasForm();
            pessoasForm.ShowDialog();
        }
    }
}

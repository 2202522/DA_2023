﻿using ProjetoDA23.Controller;
using ProjetoDA23.Model;
using ProjetoDA23.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjetoDA23
{
    public partial class MainForm : Form
    {
        CinemaContext cinemaContext;
        public MainForm()
        {
            InitializeComponent();
            cinemaContext = new CinemaContext();

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            comboBoxFuncionario.DataSource = cinemaContext.Funcionario.ToList();
            comboBoxFuncionario.ValueMember = "Id";
            comboBoxFuncionario.DisplayMember = "Nome";
        }

        private void buttonCinema_Click(object sender, EventArgs e)
        {
            this.Hide();
            CinemaForm cinemaForm = new CinemaForm();
            cinemaForm.ShowDialog();
        }

        private void buttonSalas_Click(object sender, EventArgs e)
        {
            this.Hide();
            SalasForm salasForm = new SalasForm();
            salasForm.ShowDialog();
        }

        private void buttonCategorias_Click(object sender, EventArgs e)
        {
            this.Hide();
            CategoriaForm categoriaForm = new CategoriaForm();
            categoriaForm.ShowDialog();
        }

        private void buttonFilmes_Click(object sender, EventArgs e)
        {
            this.Hide();
            FilmeForm filmeForm = new FilmeForm();
            filmeForm.ShowDialog();
        }

        private void buttonRH_Click(object sender, EventArgs e)
        {
            this.Hide();
            PessoasForm pessoasForm = new PessoasForm();
            pessoasForm.ShowDialog();
        }

        private void buttonSessões_Click(object sender, EventArgs e)
        {
            this.Hide();
            SessaoForm sessaoForm = new SessaoForm();
            sessaoForm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void buttonBilhetes_Click(object sender, EventArgs e)
        {
            this.Hide();
            BilheteForm bilheteForm = new BilheteForm();
            bilheteForm.ShowDialog();
        }
    }
}

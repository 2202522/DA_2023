﻿using ProjetoDA23.Controller;
using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoDA23.View
{
    public partial class FilmeForm : Form
    {
        CinemaContext cinemaContext;
        public FilmeForm()
        {
            InitializeComponent();
            cinemaContext = new CinemaContext();
        }

        private void listBoxFilmes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxFilmes.SelectedItem == null)
            {
                return;
            }
            else { 
            Filme filme = (Filme)listBoxFilmes.SelectedItem;

            textBoxNome.Text= filme.Nome;
            textBoxDuracao.Text= filme.Duracao.ToString();
            comboBoxCategoria.Text = filme.categoria.Nome;
            comboBoxStatus.Text= filme.Estado;
            }
        }

        private void FilmeForm_Load(object sender, EventArgs e)
        {
            var filmes = FilmeController.GetFilmes();
            listBoxFilmes.DataSource = filmes;
            var categorias = CategoriaController.GetCategorias();
            comboBoxCategoria.DataSource = categorias;
            comboBoxCategoria.ValueMember = "Id";
            comboBoxCategoria.DisplayMember = "Nome";

            comboBoxCategoria.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            Clear();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            Filme filme = (Filme)listBoxFilmes.SelectedItem;
            if (string.IsNullOrEmpty(textBoxNome.Text) || string.IsNullOrEmpty(textBoxDuracao.Text) || string.IsNullOrEmpty(comboBoxStatus.Text))
            {
                System.Windows.Forms.MessageBox.Show("Dados a vazio");
            }
            else
            {
                FilmeController.UpdateFilme(filme.Id, textBoxNome.Text, textBoxDuracao.Text, comboBoxStatus.Text, comboBoxCategoria.Text);
            }
        }
        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxNome.Text) || string.IsNullOrEmpty(textBoxDuracao.Text) || string.IsNullOrEmpty(comboBoxStatus.Text))
            {
                System.Windows.Forms.MessageBox.Show("Dados a vazio");
            }
            else
            {
                FilmeController.ADDFilme(textBoxNome.Text, textBoxDuracao.Text, comboBoxStatus.Text, comboBoxCategoria.Text);
            }
        }
        public void Clear()
        {
            textBoxNome.Text = null;
            textBoxDuracao.Text = null;
            comboBoxCategoria.Text = null;
            comboBoxStatus.Text = null;
        }
    }
}

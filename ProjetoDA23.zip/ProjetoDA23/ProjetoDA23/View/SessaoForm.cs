﻿using ProjetoDA23.Controller;
using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoDA23.View
{
    public partial class SessaoForm : Form
    {

        public SessaoForm()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                return;
            }
            else
            {
                Sessao sessao = (Sessao)listBox1.SelectedItem;
                ClearTextBoxes();
                textBoxPreco.Text = sessao.Preco.ToString();
                dateTimePicker1.Text = sessao.DataHora.ToString();
                comboBoxFilme.Text = sessao.filme.Nome;
                comboBoxSala.Text = sessao.sala.Nome;

            }
        }

        private void SessaoForm_Load(object sender, EventArgs e)
        {
            var sessoes = SessaoController.GetSessao();
            listBox1.DataSource = sessoes;

            var filmes = FilmeController.GetFilmes();
            comboBoxFilme.DataSource = filmes;
            comboBoxFilme.ValueMember = "Id";
            comboBoxFilme.DisplayMember = "Nome";
            var salas = SalaController.GetSalas();
            comboBoxSala.DataSource = salas;
            comboBoxSala.ValueMember = "Id";
            comboBoxSala.DisplayMember = "Nome";

            comboBoxFilme.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSala.DropDownStyle = ComboBoxStyle.DropDownList;
            ClearTextBoxes();
        }

        private void buttonCriar_Click(object sender, EventArgs e)
        {
            var sessoes = SessaoController.GetSessao();
            if (!SessaoController.PodeCriarSessao(comboBoxSala.Text, Convert.ToDateTime(dateTimePicker1.Text)))
            {
                System.Windows.Forms.MessageBox.Show("Sala indisponivél a essa hora");
            }
            else { 
                if (string.IsNullOrEmpty(textBoxPreco.Text) || string.IsNullOrEmpty(dateTimePicker1.Text) || string.IsNullOrEmpty(comboBoxFilme.Text) || string.IsNullOrEmpty(comboBoxSala.Text))
                {
                    System.Windows.Forms.MessageBox.Show("Dados a vazio");
                }
                else
                {
                    if (DateTime.Parse(dateTimePicker1.Text) <= DateTime.Now)
                    {
                        System.Windows.Forms.MessageBox.Show("Data Inválida");
                    }
                    else { 
                    SessaoController.ADDSessao(Convert.ToDateTime(dateTimePicker1.Text) ,Convert.ToDouble(textBoxPreco.Text), comboBoxFilme.Text, comboBoxSala.Text);
                    }
                }
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy HH:mm:ss";
        }

        private void ClearTextBoxes()
        {
            textBoxPreco.Text = null;
            dateTimePicker1.Text = null;
            comboBoxFilme.Text = null;
            comboBoxSala.Text = null;
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            Sessao sessao = (Sessao)listBox1.SelectedItem;
            SessaoController.UpdateSessao(sessao.Id, Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDouble(textBoxPreco.Text), comboBoxFilme.Text, comboBoxSala.Text);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            Sessao sessao = (Sessao)listBox1.SelectedItem;
            SessaoController.DeleteSessao(sessao.Id);
        }
    }
}

﻿using ProjetoDA23.Controller;
using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace ProjetoDA23.View
{
    public partial class CinemaForm : Form
    {
        CinemaContext cinemaContext;
        public CinemaForm()
        {
            InitializeComponent();
            cinemaContext = new CinemaContext();
        }

        private void CinemaForm_Load(object sender, EventArgs e)
        {
            var cinemas = CinemaController.GetCinemas();
            listBoxCinema.DataSource = cinemas;
            if (listBoxCinema.Items.Count < 1)
            {
                buttonCreate.Enabled = true;
                buttonUpdate.Enabled = false;
            }
            else
            {
                buttonCreate.Enabled = false;
                buttonUpdate.Enabled = true;
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            Cinema cinema = (Cinema)listBoxCinema.SelectedItem;
            CinemaController.UpdateCinema(cinema.Id, textBoxNome.Text, textBoxMorada.Text, textBoxEmail.Text);
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxNome.Text) || string.IsNullOrEmpty(textBoxMorada.Text) || string.IsNullOrEmpty(textBoxEmail.Text))
            {

                System.Windows.Forms.MessageBox.Show("Dados a vazio");

            }
            else
            {
                CinemaController.ADDCinema(textBoxNome.Text, textBoxMorada.Text, textBoxEmail.Text);
            }
        }

        private void listBoxCinema_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxCinema.SelectedItem == null)
            {
                return;
            }
            else
            {
                Cinema cinema = (Cinema)listBoxCinema.SelectedItem;
                textBoxNome.Text = cinema.Nome;
                textBoxMorada.Text = cinema.Morada;
                textBoxEmail.Text = cinema.Email;
            }
        }
    }
}

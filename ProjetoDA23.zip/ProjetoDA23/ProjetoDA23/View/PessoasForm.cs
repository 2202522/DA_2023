﻿using ProjetoDA23.Controller;
using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace ProjetoDA23.View
{
    public partial class PessoasForm : Form
    {
        CinemaContext cinemaContext;
        public PessoasForm()
        {
            InitializeComponent();
            cinemaContext = new CinemaContext();
        }

        private void PessoasForm_Load(object sender, EventArgs e)
        {
            /*if (listBoxClientes.Items.Count < 0)
            {
                buttonConsultar.Enabled = true;
            }
            else
            {
                buttonConsultar.Enabled = false;
            }*/
            
            var clientes = ClienteController.GetClientes();
            listBoxClientes.DataSource = clientes;

            var funcionarios = FuncionarioController.GetFuncionario();
            listBoxFuncionarios.DataSource = funcionarios;
            ClearTextBoxes();

        }

        private void listBoxPessoas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxFuncionarios.SelectedItem == null)
            {
                return;
            }
            else
            {
                Funcionario funcionario = (Funcionario)listBoxFuncionarios.SelectedItem;
                ClearTextBoxes();
                textBoxNome.Text = funcionario.Nome;
                textBoxMorada.Text = funcionario.Morada;
                textBoxFuncao.Text = funcionario.Funcao;
                textBoxSalario.Text = funcionario.Salario.ToString();
                
            }
        }
        private void listBoxClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxClientes.SelectedItem == null)
            {
                return;
            }
            else
            {
                Cliente cliente = (Cliente)listBoxClientes.SelectedItem;
                ClearTextBoxes();
                textBoxNome.Text = cliente.Nome;
                textBoxMorada.Text = cliente.Morada;
                textBoxNif.Text = cliente.NumFiscal.ToString();

            }
        }

        private void buttonFuncionario_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxNome.Text) || string.IsNullOrEmpty(textBoxMorada.Text) || string.IsNullOrEmpty(textBoxSalario.Text) || string.IsNullOrEmpty(textBoxFuncao.Text))
            {
                System.Windows.Forms.MessageBox.Show("Dados a vazio");
            }
            else
            {
                FuncionarioController.ADDFuncionario(textBoxNome.Text, textBoxMorada.Text, Convert.ToInt32(textBoxSalario.Text), textBoxFuncao.Text);
            }
        }
        private void buttonCliente_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxNome.Text) || string.IsNullOrEmpty(textBoxMorada.Text) || string.IsNullOrEmpty(textBoxNif.Text))
            {
                System.Windows.Forms.MessageBox.Show("Dados a vazio");
            }
            else
            {
                ClienteController.ADDCliente(textBoxNome.Text, textBoxMorada.Text, Convert.ToInt32(textBoxNif.Text));
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        public void ClearTextBoxes() {
            textBoxNome.Text = null;
            textBoxMorada.Text = null;
            textBoxFuncao.Text = null;
            textBoxSalario.Text = null;
            textBoxNif.Text = null;
        }

        private void buttonUpdateFuncionario_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = (Funcionario)listBoxFuncionarios.SelectedItem;
            FuncionarioController.UpdateFuncionario(funcionario.Id, textBoxNome.Text, textBoxMorada.Text,Convert.ToInt32(textBoxSalario.Text), textBoxFuncao.Text);
        }

        private void buttonDeleteFuncionario_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = (Funcionario)listBoxFuncionarios.SelectedItem;
            FuncionarioController.DeleteFuncionario(funcionario.Id);
        }

        private void buttonUpdateCliente_Click(object sender, EventArgs e)
        {
            Cliente cliente = (Cliente)listBoxClientes.SelectedItem;
            ClienteController.UpdateCliente(cliente.Id, textBoxNome.Text, textBoxMorada.Text, Convert.ToInt32(textBoxNif.Text));

        }

        private void buttonDeleteCliente_Click(object sender, EventArgs e)
        {
            Cliente cliente = (Cliente)listBoxClientes.SelectedItem;
            ClienteController.DeleteCliente(cliente.Id);
        }

        private void buttonConsultar_Click(object sender, EventArgs e)
        {
            this.Hide();
            ClientesForm clienteForm = new ClientesForm();
            clienteForm.ShowDialog();
        }
    }
}

﻿namespace ProjetoDA23.View
{
    partial class PessoasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxFuncionarios = new System.Windows.Forms.ListBox();
            this.buttonCliente = new System.Windows.Forms.Button();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxMorada = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxFuncao = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxSalario = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxNif = new System.Windows.Forms.TextBox();
            this.buttonConsultar = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonFuncionario = new System.Windows.Forms.Button();
            this.listBoxClientes = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonUpdateFuncionario = new System.Windows.Forms.Button();
            this.buttonUpdateCliente = new System.Windows.Forms.Button();
            this.buttonDeleteFuncionario = new System.Windows.Forms.Button();
            this.buttonDeleteCliente = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxFuncionarios
            // 
            this.listBoxFuncionarios.FormattingEnabled = true;
            this.listBoxFuncionarios.ItemHeight = 20;
            this.listBoxFuncionarios.Location = new System.Drawing.Point(12, 45);
            this.listBoxFuncionarios.Name = "listBoxFuncionarios";
            this.listBoxFuncionarios.Size = new System.Drawing.Size(385, 204);
            this.listBoxFuncionarios.TabIndex = 0;
            this.listBoxFuncionarios.SelectedIndexChanged += new System.EventHandler(this.listBoxPessoas_SelectedIndexChanged);
            // 
            // buttonCliente
            // 
            this.buttonCliente.Location = new System.Drawing.Point(182, 392);
            this.buttonCliente.Name = "buttonCliente";
            this.buttonCliente.Size = new System.Drawing.Size(164, 42);
            this.buttonCliente.TabIndex = 2;
            this.buttonCliente.Text = "Criar Cliente";
            this.buttonCliente.UseVisualStyleBackColor = true;
            this.buttonCliente.Click += new System.EventHandler(this.buttonCliente_Click);
            // 
            // textBoxNome
            // 
            this.textBoxNome.Location = new System.Drawing.Point(111, 289);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(152, 26);
            this.textBoxNome.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 292);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nome:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 337);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Morada:";
            // 
            // textBoxMorada
            // 
            this.textBoxMorada.Location = new System.Drawing.Point(111, 335);
            this.textBoxMorada.Name = "textBoxMorada";
            this.textBoxMorada.Size = new System.Drawing.Size(152, 26);
            this.textBoxMorada.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(291, 340);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Função:";
            // 
            // textBoxFuncao
            // 
            this.textBoxFuncao.Location = new System.Drawing.Point(363, 337);
            this.textBoxFuncao.Name = "textBoxFuncao";
            this.textBoxFuncao.Size = new System.Drawing.Size(152, 26);
            this.textBoxFuncao.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(291, 292);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Salario:";
            // 
            // textBoxSalario
            // 
            this.textBoxSalario.Location = new System.Drawing.Point(363, 289);
            this.textBoxSalario.Name = "textBoxSalario";
            this.textBoxSalario.Size = new System.Drawing.Size(152, 26);
            this.textBoxSalario.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(543, 292);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "NIF:";
            // 
            // textBoxNif
            // 
            this.textBoxNif.Location = new System.Drawing.Point(616, 289);
            this.textBoxNif.Name = "textBoxNif";
            this.textBoxNif.Size = new System.Drawing.Size(152, 26);
            this.textBoxNif.TabIndex = 11;
            // 
            // buttonConsultar
            // 
            this.buttonConsultar.Location = new System.Drawing.Point(616, 392);
            this.buttonConsultar.Name = "buttonConsultar";
            this.buttonConsultar.Size = new System.Drawing.Size(166, 42);
            this.buttonConsultar.TabIndex = 13;
            this.buttonConsultar.Text = "Consultar Clientes";
            this.buttonConsultar.UseVisualStyleBackColor = true;
            this.buttonConsultar.Click += new System.EventHandler(this.buttonConsultar_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(616, 440);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(166, 89);
            this.buttonBack.TabIndex = 15;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonFuncionario
            // 
            this.buttonFuncionario.Location = new System.Drawing.Point(12, 392);
            this.buttonFuncionario.Name = "buttonFuncionario";
            this.buttonFuncionario.Size = new System.Drawing.Size(164, 42);
            this.buttonFuncionario.TabIndex = 16;
            this.buttonFuncionario.Text = "Criar Funcionario";
            this.buttonFuncionario.UseVisualStyleBackColor = true;
            this.buttonFuncionario.Click += new System.EventHandler(this.buttonFuncionario_Click);
            // 
            // listBoxClientes
            // 
            this.listBoxClientes.FormattingEnabled = true;
            this.listBoxClientes.ItemHeight = 20;
            this.listBoxClientes.Location = new System.Drawing.Point(403, 45);
            this.listBoxClientes.Name = "listBoxClientes";
            this.listBoxClientes.Size = new System.Drawing.Size(385, 204);
            this.listBoxClientes.TabIndex = 17;
            this.listBoxClientes.SelectedIndexChanged += new System.EventHandler(this.listBoxClientes_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(153, 14);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "Funcionarios";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(558, 14);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 20);
            this.label7.TabIndex = 19;
            this.label7.Text = "Clientes";
            // 
            // buttonUpdateFuncionario
            // 
            this.buttonUpdateFuncionario.Location = new System.Drawing.Point(12, 440);
            this.buttonUpdateFuncionario.Name = "buttonUpdateFuncionario";
            this.buttonUpdateFuncionario.Size = new System.Drawing.Size(164, 42);
            this.buttonUpdateFuncionario.TabIndex = 21;
            this.buttonUpdateFuncionario.Text = "Update Funcionario";
            this.buttonUpdateFuncionario.UseVisualStyleBackColor = true;
            this.buttonUpdateFuncionario.Click += new System.EventHandler(this.buttonUpdateFuncionario_Click);
            // 
            // buttonUpdateCliente
            // 
            this.buttonUpdateCliente.Location = new System.Drawing.Point(182, 440);
            this.buttonUpdateCliente.Name = "buttonUpdateCliente";
            this.buttonUpdateCliente.Size = new System.Drawing.Size(164, 42);
            this.buttonUpdateCliente.TabIndex = 20;
            this.buttonUpdateCliente.Text = "Update Cliente";
            this.buttonUpdateCliente.UseVisualStyleBackColor = true;
            this.buttonUpdateCliente.Click += new System.EventHandler(this.buttonUpdateCliente_Click);
            // 
            // buttonDeleteFuncionario
            // 
            this.buttonDeleteFuncionario.Location = new System.Drawing.Point(12, 488);
            this.buttonDeleteFuncionario.Name = "buttonDeleteFuncionario";
            this.buttonDeleteFuncionario.Size = new System.Drawing.Size(164, 42);
            this.buttonDeleteFuncionario.TabIndex = 23;
            this.buttonDeleteFuncionario.Text = "Delete Funcionario";
            this.buttonDeleteFuncionario.UseVisualStyleBackColor = true;
            this.buttonDeleteFuncionario.Click += new System.EventHandler(this.buttonDeleteFuncionario_Click);
            // 
            // buttonDeleteCliente
            // 
            this.buttonDeleteCliente.Location = new System.Drawing.Point(182, 488);
            this.buttonDeleteCliente.Name = "buttonDeleteCliente";
            this.buttonDeleteCliente.Size = new System.Drawing.Size(164, 42);
            this.buttonDeleteCliente.TabIndex = 22;
            this.buttonDeleteCliente.Text = "Delete Cliente";
            this.buttonDeleteCliente.UseVisualStyleBackColor = true;
            this.buttonDeleteCliente.Click += new System.EventHandler(this.buttonDeleteCliente_Click);
            // 
            // PessoasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 549);
            this.Controls.Add(this.buttonDeleteFuncionario);
            this.Controls.Add(this.buttonDeleteCliente);
            this.Controls.Add(this.buttonUpdateFuncionario);
            this.Controls.Add(this.buttonUpdateCliente);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.listBoxClientes);
            this.Controls.Add(this.buttonFuncionario);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.buttonConsultar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxNif);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxFuncao);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxSalario);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxMorada);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxNome);
            this.Controls.Add(this.buttonCliente);
            this.Controls.Add(this.listBoxFuncionarios);
            this.Name = "PessoasForm";
            this.Text = "PessoasFoarm";
            this.Load += new System.EventHandler(this.PessoasForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxFuncionarios;
        private System.Windows.Forms.Button buttonCliente;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxMorada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxFuncao;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxSalario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxNif;
        private System.Windows.Forms.Button buttonConsultar;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonFuncionario;
        private System.Windows.Forms.ListBox listBoxClientes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonUpdateFuncionario;
        private System.Windows.Forms.Button buttonUpdateCliente;
        private System.Windows.Forms.Button buttonDeleteFuncionario;
        private System.Windows.Forms.Button buttonDeleteCliente;
    }
}
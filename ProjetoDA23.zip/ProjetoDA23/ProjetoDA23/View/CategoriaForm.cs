﻿using ProjetoDA23.Controller;
using ProjetoDA23.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoDA23.View
{
    public partial class CategoriaForm : Form
    {
        CinemaContext cinemaContext;
        public CategoriaForm()
        {
            InitializeComponent();
            cinemaContext = new CinemaContext();
        }

        private void CategoriaForm_Load(object sender, EventArgs e)
        {
            var cinemas = CategoriaController.GetCategorias();
            listBoxCategorias.DataSource = cinemas;
            comboBoxStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            textBoxNome.Text = null;
            comboBoxStatus.Text = null;
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxNome.Text) || string.IsNullOrEmpty(comboBoxStatus.Text))
            {
                System.Windows.Forms.MessageBox.Show("Dados a vazio");
            }
            else
            {
                CategoriaController.ADDCategoria(textBoxNome.Text, comboBoxStatus.Text);
                textBoxNome.Text = null;
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        private void listBoxCategorias_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxCategorias.SelectedItem == null)
            {
                return;
            }
            else { 
            Categoria categoria = (Categoria)listBoxCategorias.SelectedItem;

            textBoxNome.Text = categoria.Nome;
            comboBoxStatus.Text = categoria.Estado;
            }
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            Categoria categoria = (Categoria)listBoxCategorias.SelectedItem;
            CategoriaController.UpdateCategoria(categoria.Id, textBoxNome.Text, comboBoxStatus.Text);
        }
    }
}
